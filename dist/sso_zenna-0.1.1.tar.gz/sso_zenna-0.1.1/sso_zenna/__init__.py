"""
SSO Zenna Client - Python клиент для взаимодействия с zenna-sso API

- UserClient: OAuth 2.0 с PKCE (login/password, /me, refresh)
- ServiceClient: Client Credentials для микросервисов
- BotClient: создание пользователей и сессий Telegram (X-Bot-Service-Key)
"""

from .user_client import UserClient
from .service_client import ServiceClient
from .bot_client import BotClient
from .models import (
    UserInfo,
    TokenResponse,
    PKCEParams,
    TelegramSessionResponse,
    TelegramUserCreate,
)
from .exceptions import (
    SSOClientError,
    AuthenticationError,
    AuthorizationError,
    APIError,
    TokenError,
)

__all__ = [
    "UserClient",
    "ServiceClient",
    "BotClient",
    "UserInfo",
    "TokenResponse",
    "PKCEParams",
    "TelegramSessionResponse",
    "TelegramUserCreate",
    "SSOClientError",
    "AuthenticationError",
    "AuthorizationError",
    "APIError",
    "TokenError",
]

__version__ = "0.1.0"

