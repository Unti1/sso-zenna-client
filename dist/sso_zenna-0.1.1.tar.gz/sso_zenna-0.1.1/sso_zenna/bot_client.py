"""Клиент для бота: создание пользователей и сессий Telegram"""

from typing import Optional

from .base import BaseClient
from .models import TelegramSessionResponse, UserInfo


class BotClient(BaseClient):
    """
    Клиент для внутренних вызовов от бота.
    Требует X-Bot-Service-Key для аутентификации.
    """

    def __init__(
        self,
        base_url: str,
        bot_service_key: str,
        api_version: str = "v1",
        timeout: int = 30,
        session=None,
    ):
        super().__init__(base_url, api_version, timeout, session, auto_refresh_token=False)
        self.bot_service_key = bot_service_key

    def _get_headers(self, access_token: Optional[str] = None):
        """Заголовки с X-Bot-Service-Key"""
        headers = {"Content-Type": "application/json", "X-Bot-Service-Key": self.bot_service_key}
        return headers

    async def _refresh_token(self) -> None:
        """BotClient не поддерживает refresh"""
        raise NotImplementedError("BotClient не использует токены")

    def _get_access_token(self) -> Optional[str]:
        return None

    async def create_telegram_user(
        self,
        id: int,
        tz: int = 3,
        phone: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Optional[UserInfo]:
        """
        Создать или получить пользователя по Telegram ID.

        Returns:
            UserInfo или None при ошибке
        """
        payload = {"id": id, "tz": tz}
        if phone is not None:
            payload["phone"] = phone
        if name is not None:
            payload["name"] = name
        try:
            data = await self.post("users/telegram", json_data=payload)
            return UserInfo(**data)
        except Exception:
            return None

    async def create_telegram_session(self, user_id: int) -> Optional[TelegramSessionResponse]:
        """
        Создать сессию для web-авторизации.
        Возвращает session_token и auth_url для кнопки «Авторизоваться».

        Returns:
            TelegramSessionResponse или None при ошибке
        """
        try:
            data = await self.post(
                "auth/telegram-session",
                params={"user_id": user_id},
            )
            return TelegramSessionResponse(**data)
        except Exception:
            return None
